package mesas;
public class Mesa {
    //propiedades

    int numero;
    int comensales;


    //metodos

     // Properties
        int[][] mesas = new int[2][10]; // 2D array to store table number and quantity of diners
    publc

    for(int j=0;j < mesas.length; j++) {
            for (int i = 0; i < mesas[0].length; i++) {
                if(j==0){
                    mesas[j][i] = i;
                }else mesas[j][i] = (int)(Math.random()*5+0);
            }



       // this.numero = numero;
        //this.comensales = comensales;

    }
}
