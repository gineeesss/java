public class Coche {
    private String matricula,marca,modelo;
    private Integer km;

    public Coche(String matricula, String marca, String modelo, Integer km) {
        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
        this.km = km;
    }

    public Integer getKm() {
        return km;
    }

    public void setKm(Integer km) {
        this.km = km;
    }

    public String escribir(){
        return matricula+";"+marca+";"+modelo+";"+km;
    }

    @Override
    public String toString() {
        return "Matricula='" + matricula + '\'' +
                ", marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                ", km=" + km;
    }
}
