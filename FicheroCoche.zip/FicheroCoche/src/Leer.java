import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

public class Leer {
    static Scanner teclado = new Scanner(System.in),fichero;
    static PrintWriter log;
    static Map<String,Coche> coches = new HashMap<>();
    public static void main(String[] args) {
        int opcion;
        do {
            mostrarmenu();
            opcion = teclado.nextInt();
            switch (opcion) {
                case 1:
                    leerfichero();
                    break;
                case 2:
                    for(Coche i: coches.values()) System.out.println(i.toString());
                    break;
                case 3:
                    System.out.println("Dime la matricula");
                    if (coches.remove(teclado.next())==null) System.out.println("Lo siento pero la matricula no está");
                    else System.out.println("Coche borrado correctamente");
                    break;
                case 4:
                    List<Coche> cochesordenados=new ArrayList<>(coches.values());
                    cochesordenados.sort(new OrdenKmDesc());
                    for(Coche i: cochesordenados) System.out.println(i.toString());
                    break;
                case 0:
                    System.out.println("Gracias por utilizar el programa");
                    break;
            }
        } while (opcion != 0);
    }

    private static void mostrarmenu(){
        System.out.println("""
                1) Leer la información del fichero
                2) Mostrar la colección
                3) Eliminar un coche de la colección
                4) Ordenar los coches por km descendente
                0) Salir del programa""");
    }

    private static void leerfichero() {
        try {
            String[] lectura;
            log = new PrintWriter(new FileWriter("log.txt", true));
            fichero = new Scanner(new File("datos_coches.txt"));
            while (fichero.hasNext()){
                // leer
                lectura=fichero.nextLine().split(";");
                // guardar lo leido en la colección
                coches.putIfAbsent(lectura[0],new Coche(lectura[0],lectura[1],lectura[2],Integer.parseInt(lectura[3])));
            }

        } catch (IOException ex) {
            Date fecha = new Date();
            log.println(fecha);
            log.println(ex.getMessage());
            log.flush();
        } finally {
            if (log != null) log.close();
        }
    }
}
