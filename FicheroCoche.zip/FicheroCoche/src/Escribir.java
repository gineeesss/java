import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Escribir {
    static Scanner teclado = new Scanner(System.in).useDelimiter("\\n");
    static Map<String,Coche> coches = new HashMap<>();
    static PrintWriter fichero,log;
    public static void main(String[] args) {
        int opcion;
        do {
            mostrarmenu();
            opcion = teclado.nextInt();
            switch (opcion) {
                case 1:
                    aniadircoche();
                    break;
                case 2:
                    escribirfichero();
                    break;
                case 0:
                    System.out.println("Gracias por utilizar el programa");
                    break;
            }
        } while (opcion != 0);
    }

    private static void mostrarmenu(){
        System.out.println("""
                1) Añadir coche a la colección
                2) Volcar la información a un fichero
                0) Salir del programa""");
    }

    private static void aniadircoche(){
        String matricula,marca,modelo;
        System.out.println("Dime la matrícula");
        matricula= teclado.next();
        if(coches.containsKey(matricula)) System.out.println("Lo siento pero la matrícula ya existe");
        else{
            System.out.println("Dime la marca");
            marca= teclado.next();
            System.out.println("Dime el modelo");
            modelo= teclado.next();
            System.out.println("Dime los km que tiene el coche");
            coches.put(matricula,new Coche(matricula,marca,modelo, teclado.nextInt()));
        }
    }

    private static void escribirfichero(){
        try{
            log=new PrintWriter(new FileWriter("log.txt",true));
            fichero=new PrintWriter(new FileWriter("datos_coches.txt",true));
            for(Coche i:coches.values()){
                fichero.println(i.escribir());
            }
            fichero.flush();
        }catch (IOException ex){
            Date fecha = new Date();
            log.println(fecha);
            log.println(ex.getMessage());
            log.flush();
        }finally {
           if(log!=null) log.close();
           if(fichero!=null) fichero.close();
        }
    }

}
