import java.util.Comparator;

public class OrdenKmDesc implements Comparator<Coche> {
    @Override
    public int compare(Coche o1, Coche o2) {
        return -Integer.compare(o1.getKm(), o2.getKm());
    }
}
